package guilayout;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;


/* Doesn't do anything useful with the extra space when the window is enlarged,
   but as the window size is reduced, the elements are wrapped, just like a
   text editor.
*/

public class FlowEx {
    private JFrame theFrame = new JFrame("Flow layout");
    private JButton[] buttons = {
        new JButton("A Button"),
        new JButton("Thin"),
        new JButton("A really rather wide Button in the layout"),
        new JButton("Button four"),
        new JButton("Button five"),
        new JButton("Button six")
    };
    
    public void show() {
        theFrame.setLayout(new FlowLayout());
        for (int i = 0; i < buttons.length; i++) {
            theFrame.add(buttons[i]);
        }
        theFrame.pack(); // try without
        theFrame.setVisible(true);
        
        
    }
}
