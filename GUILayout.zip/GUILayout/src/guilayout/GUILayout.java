package guilayout;

public class GUILayout {

    public void go() {
        new BorderEx().show();
        new GridEx().show();
        new FlowEx().show();
        // Closing the BuilderLayout window, by default will shutdown the VM
        new BuilderLayout().setVisible(true);//Created with NetBeans 'JPanel Form'
        
    }
    
    public static void main(String[] args) {
        new GUILayout().go();
    }
    
}
