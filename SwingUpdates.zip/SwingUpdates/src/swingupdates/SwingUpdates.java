package swingupdates;

/* GUI systems, including swing must run in a single-threaded way */

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

public class SwingUpdates {

    private JScrollPane theScroller;
    private JFrame theFrame;
    private JButton theButton;
    private JTextArea theText;
    
    public void go() {
        theFrame = new JFrame("Swing updates");
        theFrame.setLayout(new GridLayout(2,1));
        
        theButton = new JButton("Click me");
        theText = new JTextArea("edit this");
        theScroller = new JScrollPane(theText);
        
        theButton.addActionListener(
                    new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            System.out.println("Button was clicked!");
                            System.out.println("UI thread name is: "
                                + Thread.currentThread().getName());
                            // Some time-consuming computation:
                            // adding it here (in the current thread)
                            // will freeze up the system until the 
                            // work is completed, you will not be able
                            // to interact with the GUI components until
                            // "Done...!" is printed
                            /*System.out.println("Starting...!");
                            for (int i=0; i < 50000000; i++) {
                                new Date();
                            }
                            System.out.println("Done...!");*/
                            // A solution is to embed this:
                            new SwingWorker() {
                                @Override
                                protected Object doInBackground() throws Exception {
                                    System.out.println("Starting...!");
                                    for (int i = 0; i < 50000000; i++) {
                                        new Date();
                                    }
                                    System.out.println("Done...!");
                                    return null;
                                }
                            }.execute();
                        }
                    });
        
        theFrame.add(theButton);
        theFrame.add(theScroller);
        
        theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theFrame.setBounds(10,10,300,200);
        theFrame.setVisible(true);
        System.out.println("Main thread name is: " + Thread.currentThread().getName());
        //Adding an infinite loop, the problem is that only the event thread
        //should interact with the GUI components
        for(;;) {
            try {
                //suspend the thread for 2000 milliseconds
                Thread.sleep(2000);
            } catch(InterruptedException ex) {   
            }
            // Take it on trust for now that this is the right way to interact
            // with GUI components
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    theText.append("\nTickle " + new Date()); 
                }
                
            });
            
        }
    }
    
    public static void main(String[] args) {
        new SwingUpdates().go();
    }
    
}
